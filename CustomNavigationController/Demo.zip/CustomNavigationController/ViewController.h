//
//  ViewController.h
//  CustomNavigationController
//
//  Created by Pradeep Kumar Yadav on 11/05/15.
//  Copyright (c) 2015 Pradeep Kumar Yadav. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)showLandscapeViewButtonClicked:(id)sender;

@end

