//
//  CustomNavigationControllerViewController.m
//
//
//  Created by Pradeep Kumar Yadav
//

#import "CustomNavigationControllerViewController.h"

@interface CustomNavigationControllerViewController ()

@end

@implementation CustomNavigationControllerViewController

//- (NSUInteger)supportedInterfaceOrientations
//{
//    return UIInterfaceOrientationMaskLandscape;
//    
//}

- (BOOL)shouldAutorotate NS_AVAILABLE_IOS(6_0) {
    return [self.topViewController shouldAutorotate];
}
-(UIInterfaceOrientationMask)supportedInterfaceOrientations{
    return [self.topViewController supportedInterfaceOrientations];
}
// Returns interface orientation masks.
- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation NS_AVAILABLE_IOS(6_0) {
    return [self.topViewController preferredInterfaceOrientationForPresentation];
}

@end
